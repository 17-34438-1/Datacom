﻿using System;
using AnotherAssembly;

namespace Access_Modifiers_Example
{
    class GStudent:Student
    {
        public void GS()
        {
     
            this.name = "def";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            GStudent s = new GStudent();
            s.GS();
           
        }
    }
}
