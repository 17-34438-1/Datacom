﻿using System;


namespace AnotherAssembly
{
     public class Student
    {
        protected internal string name;
    }


      public class UGStudent
     {
         public void M()
         {
            
         }
     }
}
