A1=2;
f=2360;

B=0.4;
fh=4720;
t=0:pi/100:5*pi;
%x1=A1*sin(2*pi*f*t);
%t=0:pi/100:5*pi;
xh=B*sin(2*pi*fh*t);

%plot(t,x1);
plot(t,xh);