f=400;
fs=8000;
fh=2000;
a=3.0;
b=0.1;
c=0.4;

t=0:1/fs:1-1/fs;
L= 2;
bw=0.992;
h=c*sin(2*pi*fh*t);
x1=a*sin(2*pi*f*t);
noise=b*rand(size(x1));
y= x1+noise+h;


%HD=(c^2/2)/(a^2/2);
%HDdb=10*log10(HD);
%validate=thd(y);
%validate=16.9897;



ND=((a^2)/2)/((b^2)+((c^2)/2))
NDdb= 10*log10(ND)
validate = sinad(y)
result=[NDdb validate]
%%Bandwidth = obw(y,fs)

%Bitrate=2*bw*log2(L)
%SNR=a^2/2/b^2
%SNRdb=10*log10(SNR)
%capacity=bw*log2(1+SNR)


