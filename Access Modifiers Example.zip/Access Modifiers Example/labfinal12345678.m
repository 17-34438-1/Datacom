f=5;
f2=10;
x=[0 0 0 0 1 0 1 0] % input signal ; 
nx=size(x,2); 
 bp=.000001;
bsp=[];
for n=1:1:length(x)
    if x(n)==1;
        se=ones(1,100);
    else x(n)==0;
        se=zeros(1,100);
    end
    bsp=[bsp se];
end
t1=bp/100:bp/100:100*length(x)*(bp/100);
subplot(4,1,1);
plot(t1,bsp,'linewidth',2.5);
grid on;
axis([0 bp*length(x) -.5 1.5]);
i=1;
while i<nx+1  
    t = i:0.001:i+1;    
    if x(i)==1       
        ask=sin(2*pi*f*t);   
        fsk=sin(2*pi*f*t);
        psk=sin(2*pi*f*t);
    else
        ask=zeros(1,length(t)); 
        fsk=sin(2*pi*f2*t);
        psk=sin(2*pi*(f+3*pi/180)*t);
    end
    
    subplot(4,1,2);
     title('Amplitude Shift Key')
     plot(t,ask);
      hold on;
      grid on;
       
      subplot(4,1,3);
       title('Frequency Shift Key')
       plot(t,fsk);
      hold on;
       grid on;
       
        subplot(4,1,4);
         title('Phase Shift Key')
         plot(t,psk);
       hold on;
       grid on;

  axis([1 9 -1 1]);
  i=i+1;
end 