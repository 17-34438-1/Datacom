f=5;
f2=10;
x=[0 1 0 0 1 0 1 1] % input signal ; 
nx=size(x,2); 
 
i=1;
while i<nx+1  
    t = i:0.001:i+1;    
    if x(i)==1       
        ask=sin(2*pi*f*t);   
        fsk=sin(2*pi*f*t);
        psk=sin(2*pi*f*t);
    else
        ask=zeros(1,length(t)); 
        fsk=sin(2*pi*f2*t);
        psk=sin(2*pi*(f+3*pi/180)*t);
    end
    
    subplot(3,1,1);
     title('Amplitude Shift Key')
     plot(t,ask);
      hold on;
      grid on;
       
      subplot(3,1,2);
       title('Frequency Shift Key')
       plot(t,fsk);
      hold on;
       grid on;
       
        subplot(3,1,3);
         title('Phase Shift Key')
         plot(t,psk);
       hold on;
       grid on;
    axis([1 10 -1 1]);
   
         i=i+1;
end 