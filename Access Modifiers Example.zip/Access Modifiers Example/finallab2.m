x=[0 1 0 1 0 1 0];
bp=.000001;
bsp=[];
f=5;
f2=10;
for n=1:1:length(x)
    if x(n)==1;
        se=ones(1,100);
        ask=sin(2*pi*f*100);   
        
    else x(n)==0;
        se=zeros(1,100);
         ask=zeros(1,100); 
       
    end
    bsp=[bsp se];
end
t1=bp/100:bp/100:100*length(x)*(bp/100);
subplot(3,1,1);
plot(t1,bsp,'linewidth',2.5);
grid on;



subplot(3,1,2);
     title('Amplitude Shift Key')
     plot(100,ask);
      hold on;
      grid on;
       
      
      
axis([0 bp*length(x) -.5 1.5]);
ylabel('amplitude(volt)'); 
xlabel(' time(sec)'); 
title('transmitting information as digital signal'); 

