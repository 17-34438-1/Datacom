dec=double('R')
p=2.^(0:-1:-7)
b=floor(p'*dec)
B=mod(dn,2)
dn=reshape(B,1,numel(B))

