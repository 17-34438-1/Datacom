function dn= abcd(text)
dec=double(text)
p=2.^(0:-1:-7)
b=floor(p'*dec)
B=mod(b,2)
dn=reshape(B,1,numel(B)) 

end
